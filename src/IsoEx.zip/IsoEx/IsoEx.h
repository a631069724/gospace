#ifndef __ISO_EX_H__
#define __ISO_EX_H__

#define MAX_ISO_DATA	(1024 * 1)
#define MIN_ISO_LEN	10
#define FIELD_MAX_SIZE	512

#define ISO_LEN_MASK	0x03 /*The Mask Is:When LenType = (Iso->type >> 6)*/
#define ISO_LEN_FIX	0x00
#define ISO_LEN_VAR2	0x01
#define ISO_LEN_VAR3	0x02

/*���³�������ֻ��ѡһ��*/
#define ISOLV3		0x80
#define ISOLV2		0x40
#define	ISOLFIX		0x00

/*������������ֻ��ѡһ��*/
#define ISO_DATA_MASK	0x3C /*The Mask Is:When DatType = (Iso->type & 0x3F)*/
#define ISODEBC		0x20
#define ISODBIN		0x10
#define ISODBCD		0x08
#define ISODC_D		0x04
#define ISODASC		0x00

/*�����������ֻ��ѡһ��*/
#define ISO_FIL_MASK	0x02 /*The Mask Is:When DatType = (Iso->type & 0x3F)*/
#define ISOFSP		0x02
#define ISOF0		0x00

/*���¶�������ֻ��ѡһ��*/
#define ISO_JUST_MASK	0x01 /*The Mask Is:When DatType = (Iso->type & 0x3F)*/
#define ISORJUST	0x01
#define ISOLJUST	0x00

typedef struct {
	short len;
	unsigned char type;
} IsoTabEx;

typedef struct {
	short bitf;
	short len;
	short off;
} IsoField;

typedef struct {
	unsigned char dbuf[MAX_ISO_DATA];
	short		off;
#define BCDMSG	0
#define ASCMSG	1
	int		msgtype;
#define BCDBIT	0
#define ASCBIT	1
	int		bittype;
#define BCDVAR	0
#define ASCVAR	1
#define HEXVAR	2
	int		vartype;
	char		msgid[5];
	IsoField	f[128];
	IsoTabEx	*deftab;

} IsoEx;

void EBcd2Asc(char *outstr,char *instr,int lenth);
void Asc2EBcd(char *outstr,char *instr,int lenth);
void AtoE(char *s,int len);
void EtoA(char *s,int len);
void Asc2Bcd(unsigned char *bcd, unsigned char *asc, int len, int r_align);
void Bcd2Asc(unsigned char *asc, unsigned char *bcd, int len, int r_align);
int InitIsoEx( IsoEx *Iso, int MsgType, int BitType,
			int VarType, IsoTabEx *DefIso);
int Str2IsoEx( IsoEx *Iso, unsigned char *dStr, int inLen );
int Iso2StrEx(IsoEx *Iso, unsigned char *dStr, int CanUseLen );
int SetBitEx(IsoEx *Iso, int nBitNo, char *sData, int len);
int GetBitEx(IsoEx *Iso, int nBitNo, char *rData , int MaxLen);
int ExportIso( char *TabName, IsoTabEx *IsoDefEx);

#endif
