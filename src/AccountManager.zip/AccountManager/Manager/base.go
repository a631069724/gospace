package Manager

type Client interface {
	Start()
	SubscribeMarketData([]string)
}
