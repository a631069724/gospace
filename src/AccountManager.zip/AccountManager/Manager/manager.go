package Manager

import (
	"AccountManager/ctptran"
	"fmt"
)

type MyManager struct {
	client Client
}

func NewManager() *MyManager {
	client, err := ctptran.NewCtpClient("D:\\mygo\\src\\AccountManager\\ctptran\\confg.ini")
	if err != nil {
		fmt.Println("New Client Error")
		return nil
	}
	return &MyManager{
		client: client,
	}
}

func (m *MyManager) Run() {
	m.client.Start()
	m.client.SubscribeMarketData
	fmt.Println("Server Running...")

}
