package hkapi

import (
	"fmt"
	"housekeeper/manager"
	"log"
	"net/http"
	"strconv"
)

var hk *manager.HouseKeeper

func HttpApiRegist(h *manager.HouseKeeper) {
	hk = h
}

func HandleList() {
	http.HandleFunc("/addrule", AddRule)
	http.HandleFunc("/addaccount", AddRule)
}

func Run() {
	HandleList()
	http.ListenAndServe(hk.GetHttpAddr(), nil)
}

func AddRule(w http.ResponseWriter, r *http.Request) {
	r.ParseForm()
	log.Println(r.Form)
	if fflvl, err := strconv.ParseFloat(r.Form["flvl"], 64); err != nil {
		fmt.Fprintln(w, "flvl err")
	}
	if fblvl, err := strconv.ParseFloat(r.Form["blvl"], 64); err != nil {
		fmt.Fprintln(w, "blvl err")
	}
	if fmulilvl, err := strconv.ParseFloat(r.Form["mulilvl"], 64); err != nil {
		fmt.Fprintln(w, "mulilvl err")
	}

	urule := manager.NewRule(r.Form["id"], r.Form["account"], r.Form["type"], fflvl, fblvl, fmulilvl, r.Form["starttime"], r.Form["endtime"])
	hk.AddRule("gengzhi", urule)
	fmt.Fprintf(w, `{
		"code":"%s",
		"msg":"%s"
	}`, "00", "success")

}

func AddAcount(w http.ResponseWriter, r *http.Request) {
	r.ParseForm()
	log.Println(r.Form)
	uname := r.Form["uname"]
	if !hk.KeeperExist(uname) {
		hk.AddKeeper(uname, NewKeeper(uname))
	}

	uacc := NewAccount(r.Form["account"], r.Form["pwd"], "9999", "CTP", r.Form["certinfo"], r.Form["ip"], r.Form["port"])

	log.Println("keeper:", uname, "Add Account", uacc)
	if uacc != nil {
		uacc.MyInit()
		uacc.SetQuoter(hk.GetQuoter())
		hk.AddAccount(uname, uacc)
		fmt.Fprintf(w, `{
			"code":"%s",
			"msg":"%s"
		}`, "00", "success")

	} else {
		fmt.Fprintf(w, `{
			"code":"%s",
			"msg":"%s"
		}`, "01", "error info")

	}
}
