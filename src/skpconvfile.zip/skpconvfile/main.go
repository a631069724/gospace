package main

import "skpconvfile/skp"

func main() {
	skp.Run()
}
