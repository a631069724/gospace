package conver

type Conver interface {
	Conver() error
}
